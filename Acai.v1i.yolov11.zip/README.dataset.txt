# Açaí > 2026-07-02 1:52pm
https://universe.roboflow.com/rafaels-workspace-solhy/acai-zwrcf

Provided by a Roboflow user
License: CC BY 4.0

